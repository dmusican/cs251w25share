Copyright (c) 2024, David Liben-Nowell, Dave Musicant, Anna Rafferty, James Ryan, Jed Yang, Laura Effinger-Dean.  
All rights reserved.

You may not post this code, or any code you build using it, in any publicly viewable capacity online or otherwise. This means in particular that you may not post your solution to this assignment publicly on GitHub or any other online location for others to see.

You are permitted to use this code for purposes of completing class assignments.

You may wish for potential employers to view the work that you have done. If you wish to share your work with potential employers, you need to do so in some kind of private manner. I recommend making a Google Drive folder that requires a precise link to access it, and that you share the link only with employers via a [[https://bitly.com/][shortened link]] or a QR code on your resume. If you really wish to do so via GitHub, use a private repository, then use [[https://gitfront.io][gitfront.io]] to generate a link to it.
