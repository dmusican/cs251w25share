You may not post this code, or any code you build using it, in any publicly viewable capacity online or otherwise. This means in particular that you may not post your solution to this assignment on GitHub or any other online location for others to see. 

See the [license file](LICENSE.md) for more information.
